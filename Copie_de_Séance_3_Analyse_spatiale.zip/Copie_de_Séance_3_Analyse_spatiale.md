
# Séance 3 / Analyse spatiale avancée

## Configuration de l'environnement de travail






```python
#Initialisation de l'environnement avec geopandas
!apt update
!apt install gdal-bin python-gdal python3-gdal 
# Install rtree - Geopandas requirment
!apt install python3-rtree 
# Install Geopandas
!pip install git+git://github.com/geopandas/geopandas.git
# Instal contextily (fonds de carte)
!pip install contextily
# Install mapclassify (cartographie thématique)
!pip install mapclassify
#Depuis sa version 0.8, Geopandas peut fonctionner de manière expérimental avec Pygeos ce qui accèlère certaines opérations
!pip install pygeos
```


```python
#Importation des librairies nécessaires
import pandas as pd #Gestion de données
import matplotlib.pyplot as plt #Visualisation de données
import geopandas as gpd #Gestion données sptiales
import contextily as ctx #Fond de carte
import mapclassify # Cartographie thémtique
import os
import numpy as np
import shapely
import pygeos
```

## Importation et préparation des données de la séance


```python
#Téléchargement des datas depuis le site opendata de Paris
!wget -O velibs.geojson https://opendata.paris.fr/explore/dataset/velib-disponibilite-en-temps-reel/download/?format=geojson&timezone=Europe/Berlin&lang=fr
!wget -O IRIS.geojson https://data.iledefrance.fr/explore/dataset/iris/download/?format=geojson&refine.dep=75&timezone=Europe/Berlin&lang=fr 
!wget -O pistescyclables.geojson https://opendata.paris.fr/explore/dataset/reseau-cyclable/download/?format=geojson&timezone=Europe/Berlin&lang=fr
```


```python
#Importer la couche des IRIS

IRIS= gpd.read_file("IRIS.geojson", encoding='utf-8')
IRIS.plot()
IRIS.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((2.35084 48.86334, 2.35095 48.86340, ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((2.36789 48.85827, 2.36811 48.85739, ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POLYGON ((2.35855 48.85022, 2.35757 48.85056, ...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((2.35166 48.84660, 2.35279 48.84595, ...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((2.33699 48.85387, 2.33692 48.85452, ...</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_6_1.png)



```python
#Garder les IRIS de Paris

IRISPARIS = IRIS[(IRIS["dep"] == 75)]
IRISPARIS.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f7116e0bad0>




![png](output_7_1.png)



```python
#Importer la couche des velibs

Velibs= gpd.read_file("velibs.geojson", encoding='utf-8')
Velibs.plot()
Velibs.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>21</td>
      <td>Toudouze - Clauzel</td>
      <td>Paris</td>
      <td>3</td>
      <td>1</td>
      <td>9020</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>18</td>
      <td>2021-03-05T08:41:58+00:00</td>
      <td>OUI</td>
      <td>POINT (2.33736 48.87930)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>0</td>
      <td>0</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>35</td>
      <td>2021-03-05T08:19:43+00:00</td>
      <td>OUI</td>
      <td>POINT (2.27572 48.86598)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>5</td>
      <td>46</td>
      <td>Harpe - Saint-Germain</td>
      <td>Paris</td>
      <td>21</td>
      <td>16</td>
      <td>5001</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>22</td>
      <td>2021-03-05T08:46:34+00:00</td>
      <td>OUI</td>
      <td>POINT (2.34367 48.85152)</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_8_1.png)



```python
#Ne garder que les stations de Velibs de la ville de Paris (sélection par localisation)

VelibParis = gpd.overlay(Velibs, IRISPARIS, how='intersection')
VelibParis.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f7116d67e10>




![png](output_9_1.png)



```python
#Importer la couche des pistes cyclables

pistescyclables= gpd.read_file("pistescyclables.geojson", encoding='utf-8')
pistescyclables.plot()
pistescyclables.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bois</th>
      <th>voie</th>
      <th>arrdt</th>
      <th>sens_velo</th>
      <th>statut</th>
      <th>date_de_livraison</th>
      <th>typologie_simple</th>
      <th>longueur_du_troncon_en_km</th>
      <th>bidirectionnel</th>
      <th>length</th>
      <th>piste</th>
      <th>couloir_bus</th>
      <th>type_continuite</th>
      <th>circulation</th>
      <th>position</th>
      <th>reseau</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Non</td>
      <td>RUE D EUPATORIA</td>
      <td>20.0</td>
      <td>Contresens</td>
      <td>Zone 30</td>
      <td>2010-12-31</td>
      <td>Autres itinéraires cyclables (ex : Aires piéto...</td>
      <td>0.153156</td>
      <td>Non</td>
      <td>153.155736</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (2.38819 48.86904, 2.38817 48.86904...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>None</td>
      <td>Rue Tagore</td>
      <td>13.0</td>
      <td>Contresens</td>
      <td>Zone 30</td>
      <td>2020-03-31</td>
      <td>Autres itinéraires cyclables (ex : Aires piéto...</td>
      <td>0.140340</td>
      <td>None</td>
      <td>140.339730</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (2.36102 48.82078, 2.36091 48.82075...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>None</td>
      <td>Rue Auguste Perret</td>
      <td>13.0</td>
      <td>Contresens</td>
      <td>Zone 30</td>
      <td>2020-03-31</td>
      <td>Autres itinéraires cyclables (ex : Aires piéto...</td>
      <td>0.213154</td>
      <td>None</td>
      <td>213.154483</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (2.35796 48.82446, 2.35842 48.82457...</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_10_1.png)



```python
# Créer une couche des arrondissements

ARDT = IRISPARIS.dissolve(by='nom_com')
ARDT.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f71169fb2d0>




![png](output_11_1.png)


## Calcul de surface, de longueur


```python
#Calculer la surface des IRIS avec une reprojection en amont

IRIS = IRISPARIS.to_crs(2154)
IRIS["surface"] = IRIS['geometry'].area/1000000
IRIS.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>surface</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((652375.500 6862786.000, 652383.300 6...</td>
      <td>0.043852</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((653621.380 6862212.150, 653637.290 6...</td>
      <td>0.065652</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POLYGON ((652928.990 6861322.000, 652857.900 6...</td>
      <td>0.091055</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((652420.000 6860923.400, 652502.600 6...</td>
      <td>0.048930</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((651350.400 6861741.500, 651346.000 6...</td>
      <td>0.082562</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Calculer la longueur des tronçons des pistes cyclables

pistescyclables = pistescyclables.to_crs(2154)
pistescyclables["longueur"] = pistescyclables['geometry'].length
pistescyclables.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bois</th>
      <th>typologie_simple</th>
      <th>arrdt</th>
      <th>sens_velo</th>
      <th>statut</th>
      <th>voie</th>
      <th>longueur_du_troncon_en_km</th>
      <th>bidirectionnel</th>
      <th>length</th>
      <th>piste</th>
      <th>position</th>
      <th>date_de_livraison</th>
      <th>couloir_bus</th>
      <th>reseau</th>
      <th>type_continuite</th>
      <th>circulation</th>
      <th>geometry</th>
      <th>longueur</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Non</td>
      <td>Bandes cyclables</td>
      <td>9.0</td>
      <td>Contresens</td>
      <td>Zone 30</td>
      <td>RUE DE PROVENCE</td>
      <td>0.175731</td>
      <td>Non</td>
      <td>175.730790</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (651237.609 6864009.456, 651062.121...</td>
      <td>175.730790</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Non</td>
      <td>Pistes cyclables</td>
      <td>13.0</td>
      <td>None</td>
      <td>Voie 50</td>
      <td>BOULEVARD VINCENT AURIOL</td>
      <td>0.005123</td>
      <td>Oui</td>
      <td>5.123270</td>
      <td>Niveau trottoir</td>
      <td>Axial</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (652760.479 6859176.047, 652762.699...</td>
      <td>5.123270</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Non</td>
      <td>Bandes cyclables</td>
      <td>13.0</td>
      <td>Sens de circulation générale</td>
      <td>Voie 50</td>
      <td>AVENUE D ITALIE</td>
      <td>0.044163</td>
      <td>Non</td>
      <td>44.162896</td>
      <td>None</td>
      <td>None</td>
      <td>2005-12-31</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (652885.503 6858330.855, 652894.076...</td>
      <td>44.162896</td>
    </tr>
  </tbody>
</table>
</div>



## Transformations géométriques


```python
# Créer une couche de centroides des IRIS

IRIScentro = IRIS.copy()
IRIScentro.geometry = IRIScentro['geometry'].centroid
IRIScentro.plot(column = "nom_com")
IRIScentro.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>surface</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POINT (652470.831 6862667.679)</td>
      <td>0.043852</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POINT (653516.646 6862084.841)</td>
      <td>0.065652</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POINT (652789.907 6861492.890)</td>
      <td>0.091055</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POINT (652550.522 6860731.161)</td>
      <td>0.048930</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POINT (651433.961 6861949.340)</td>
      <td>0.082562</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_16_1.png)



```python
# Créer une paire de coordonées géographique en WGS84 pour la couche des IRIS (en 2154)

IRIScentro["Longitude"] = IRIScentro['geometry'].to_crs(4326).x
IRIScentro["Latitude"] = IRIScentro['geometry'].to_crs(4326).y
IRIScentro.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>surface</th>
      <th>Longitude</th>
      <th>Latitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POINT (652470.831 6862667.679)</td>
      <td>0.043852</td>
      <td>2.352154</td>
      <td>48.862287</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POINT (653516.646 6862084.841)</td>
      <td>0.065652</td>
      <td>2.366472</td>
      <td>48.857122</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POINT (652789.907 6861492.890)</td>
      <td>0.091055</td>
      <td>2.356633</td>
      <td>48.851746</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POINT (652550.522 6860731.161)</td>
      <td>0.048930</td>
      <td>2.353456</td>
      <td>48.844878</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POINT (651433.961 6861949.340)</td>
      <td>0.082562</td>
      <td>2.338104</td>
      <td>48.855750</td>
    </tr>
  </tbody>
</table>
</div>



## Jointure spatiale et agrégation statistique


```python
# Jointure spatiale Velibs <> IRIS

Velibok = gpd.sjoin(VelibParis, IRISPARIS)
Velibok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>iris_left</th>
      <th>nom_iris_left</th>
      <th>typ_iris_left</th>
      <th>dep_left</th>
      <th>insee_com_left</th>
      <th>nom_com_left</th>
      <th>code_iris_left</th>
      <th>geometry</th>
      <th>index_right</th>
      <th>iris_right</th>
      <th>nom_iris_right</th>
      <th>typ_iris_right</th>
      <th>dep_right</th>
      <th>insee_com_right</th>
      <th>nom_com_right</th>
      <th>code_iris_right</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2</td>
      <td>55</td>
      <td>André Mazet - Saint-André des Arts</td>
      <td>Paris</td>
      <td>23</td>
      <td>21</td>
      <td>6015</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>32</td>
      <td>2021-03-04T09:42:08+00:00</td>
      <td>OUI</td>
      <td>2103</td>
      <td>Monnaie 3</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062103</td>
      <td>POINT (2.33910 48.85376)</td>
      <td>2057</td>
      <td>2103</td>
      <td>Monnaie 3</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062103</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>23</td>
      <td>Pont de Lodi - Dauphine</td>
      <td>Paris</td>
      <td>14</td>
      <td>11</td>
      <td>6014</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>8</td>
      <td>2021-03-04T09:42:00+00:00</td>
      <td>OUI</td>
      <td>2103</td>
      <td>Monnaie 3</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062103</td>
      <td>POINT (2.33995 48.85530)</td>
      <td>2057</td>
      <td>2103</td>
      <td>Monnaie 3</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062103</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>2</td>
      <td>1</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>32</td>
      <td>2021-03-04T09:39:59+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (2.27572 48.86598)</td>
      <td>2787</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>18</td>
      <td>Flandrin - Henri Martin</td>
      <td>Paris</td>
      <td>6</td>
      <td>3</td>
      <td>16018</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>12</td>
      <td>2021-03-04T09:41:16+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (2.27242 48.86433)</td>
      <td>2787</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>20</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>Paris</td>
      <td>1</td>
      <td>0</td>
      <td>11104</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>19</td>
      <td>2021-03-04T09:39:56+00:00</td>
      <td>OUI</td>
      <td>4411</td>
      <td>Sainte-Marguerite 11</td>
      <td>H</td>
      <td>75</td>
      <td>75111</td>
      <td>Paris 11e Arrondissement</td>
      <td>751114411</td>
      <td>POINT (2.39257 48.85591)</td>
      <td>2128</td>
      <td>4411</td>
      <td>Sainte-Marguerite 11</td>
      <td>H</td>
      <td>75</td>
      <td>75111</td>
      <td>Paris 11e Arrondissement</td>
      <td>751114411</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Réorganiser la table 

Velibok = Velibok[["stationcode", "name", "capacity", "numbikesavailable", "numdocksavailable", "nom_com_left", "nom_iris_left", "geometry"]]
Velibok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stationcode</th>
      <th>name</th>
      <th>capacity</th>
      <th>numbikesavailable</th>
      <th>numdocksavailable</th>
      <th>nom_com_left</th>
      <th>nom_iris_left</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6015</td>
      <td>André Mazet - Saint-André des Arts</td>
      <td>55</td>
      <td>23</td>
      <td>32</td>
      <td>Paris 6e Arrondissement</td>
      <td>Monnaie 3</td>
      <td>POINT (2.33910 48.85376)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6014</td>
      <td>Pont de Lodi - Dauphine</td>
      <td>23</td>
      <td>14</td>
      <td>8</td>
      <td>Paris 6e Arrondissement</td>
      <td>Monnaie 3</td>
      <td>POINT (2.33995 48.85530)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>16107</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>35</td>
      <td>2</td>
      <td>32</td>
      <td>Paris 16e Arrondissement</td>
      <td>Porte Dauphine 4</td>
      <td>POINT (2.27572 48.86598)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16018</td>
      <td>Flandrin - Henri Martin</td>
      <td>18</td>
      <td>6</td>
      <td>12</td>
      <td>Paris 16e Arrondissement</td>
      <td>Porte Dauphine 4</td>
      <td>POINT (2.27242 48.86433)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>11104</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>20</td>
      <td>1</td>
      <td>19</td>
      <td>Paris 11e Arrondissement</td>
      <td>Sainte-Marguerite 11</td>
      <td>POINT (2.39257 48.85591)</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Renommer les colonnes

Velibok = Velibok.rename(columns={'Code_Station': 'ID_Station', 'name':'Nom', 'capacity':'Capacite', 'numbikesavailable': 'nbVelos','numdocksavailable': 'Nbemplacements', 'nom_com_left': 'Arrondissement', 'nom_iris_left':'IRIS'})
Velibok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>stationcode</th>
      <th>Nom</th>
      <th>Capacite</th>
      <th>nbVelos</th>
      <th>Nbemplacements</th>
      <th>Arrondissement</th>
      <th>IRIS</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>6015</td>
      <td>André Mazet - Saint-André des Arts</td>
      <td>55</td>
      <td>23</td>
      <td>32</td>
      <td>Paris 6e Arrondissement</td>
      <td>Monnaie 3</td>
      <td>POINT (2.33910 48.85376)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>6014</td>
      <td>Pont de Lodi - Dauphine</td>
      <td>23</td>
      <td>14</td>
      <td>8</td>
      <td>Paris 6e Arrondissement</td>
      <td>Monnaie 3</td>
      <td>POINT (2.33995 48.85530)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>16107</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>35</td>
      <td>2</td>
      <td>32</td>
      <td>Paris 16e Arrondissement</td>
      <td>Porte Dauphine 4</td>
      <td>POINT (2.27572 48.86598)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>16018</td>
      <td>Flandrin - Henri Martin</td>
      <td>18</td>
      <td>6</td>
      <td>12</td>
      <td>Paris 16e Arrondissement</td>
      <td>Porte Dauphine 4</td>
      <td>POINT (2.27242 48.86433)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>11104</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>20</td>
      <td>1</td>
      <td>19</td>
      <td>Paris 11e Arrondissement</td>
      <td>Sainte-Marguerite 11</td>
      <td>POINT (2.39257 48.85591)</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Faire deux cartes (stations catégorisées par Arrondissement et par IRIS) pour vérification

Velibok.plot(figsize=(10,10),column='Arrondissement', markersize= 3, legend=False)
Velibok.plot(figsize=(10,10),column='IRIS', markersize=3,  legend=False)

```




    <matplotlib.axes._subplots.AxesSubplot at 0x7f2f2769fc90>




![png](output_22_1.png)



![png](output_22_2.png)



```python
# Compter le nombre de stations de vélibs par IRIS

Nbvelib  = Velibok[["IRIS", "stationcode"]].groupby("IRIS").size()
Nbvelib =pd.DataFrame(Nbvelib)
Nbvelib = Nbvelib.rename(columns={0: 'Nbstations'})
Nbvelib.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Nbstations</th>
    </tr>
    <tr>
      <th>IRIS</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Amerique 11</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Amerique 13</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Amerique 14</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Amerique 18</th>
      <td>1</td>
    </tr>
    <tr>
      <th>Amerique 19</th>
      <td>3</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Verification somme

total1 = VelibParis['stationcode'].count()
total2 = Nbvelib['Nbstations'].sum()

print(total1)
print(total2)
```

    998
    998
    


```python
# Calculer la capacité des stations de vélibs par IRIS (résumé statistique)

Nbvelib  = Velibok[["IRIS", "Capacite"]].groupby("IRIS").sum()
Nbvelib =pd.DataFrame(Nbvelib)
Nbvelib = Nbvelib.rename(columns={0: 'NbVelibs'})
Nbvelib.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Capacite</th>
    </tr>
    <tr>
      <th>IRIS</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Amerique 11</th>
      <td>28</td>
    </tr>
    <tr>
      <th>Amerique 13</th>
      <td>18</td>
    </tr>
    <tr>
      <th>Amerique 14</th>
      <td>17</td>
    </tr>
    <tr>
      <th>Amerique 18</th>
      <td>17</td>
    </tr>
    <tr>
      <th>Amerique 19</th>
      <td>94</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Verification somme

total1 = VelibParis['capacity'].sum()
total2 = Nbvelib['Capacite'].sum()

print(total1)
print(total2)
```

    32179
    32179
    


```python
# Faire la jointure attributaire

IRISbis = IRISPARIS.merge(Nbvelib, left_on='nom_iris', right_on='IRIS')
IRISbis.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>Capacite</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((2.35084 48.86334, 2.35095 48.86340, ...</td>
      <td>26</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((2.36789 48.85827, 2.36811 48.85739, ...</td>
      <td>51</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((2.35166 48.84660, 2.35279 48.84595, ...</td>
      <td>74</td>
    </tr>
    <tr>
      <th>3</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((2.33699 48.85387, 2.33692 48.85452, ...</td>
      <td>28</td>
    </tr>
    <tr>
      <th>4</th>
      <td>3805</td>
      <td>Porte Saint-Denis 5</td>
      <td>H</td>
      <td>75</td>
      <td>75110</td>
      <td>Paris 10e Arrondissement</td>
      <td>751103805</td>
      <td>POLYGON ((2.35143 48.87711, 2.35123 48.87643, ...</td>
      <td>11</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Cartographier la capacité des stations de vélibs par IRIS

IRISbis.geometry = IRISbis['geometry'].centroid

Carte1, ax = plt.subplots(figsize=(18,16))
IRISPARIS.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.1, color = 'black')
IRISbis.to_crs('EPSG:3857').plot(ax=ax, markersize="Capacite", column="Capacite", alpha=1, cmap='Spectral_r',scheme='quantiles', categorical=False, legend=True)
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```

    /usr/local/lib/python3.7/dist-packages/ipykernel_launcher.py:3: UserWarning: Geometry is in a geographic CRS. Results from 'centroid' are likely incorrect. Use 'GeoSeries.to_crs()' to re-project geometries to a projected CRS before this operation.
    
      This is separate from the ipykernel package so we can avoid doing imports until
    


![png](output_28_1.png)


## Exercice autour des pistes cyclables

* Faire la jointure spatiale (pistes cyclables <> IRIS
* Calculer la somme des longueurs de pistes cyclable par IRIS
* Cartographier cet indicateur


```python
# Jointure spatiale Velibs <> IRIS

pistescyclablesok = gpd.sjoin(pistescyclables, IRIS)
pistescyclablesok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>bois</th>
      <th>typologie_simple</th>
      <th>arrdt</th>
      <th>sens_velo</th>
      <th>statut</th>
      <th>voie</th>
      <th>longueur_du_troncon_en_km</th>
      <th>bidirectionnel</th>
      <th>length</th>
      <th>piste</th>
      <th>position</th>
      <th>date_de_livraison</th>
      <th>couloir_bus</th>
      <th>reseau</th>
      <th>type_continuite</th>
      <th>circulation</th>
      <th>geometry</th>
      <th>longueur</th>
      <th>index_right</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>surface</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Non</td>
      <td>Bandes cyclables</td>
      <td>9.0</td>
      <td>Contresens</td>
      <td>Zone 30</td>
      <td>RUE DE PROVENCE</td>
      <td>0.175731</td>
      <td>Non</td>
      <td>175.730790</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (651237.609 6864009.456, 651062.121...</td>
      <td>175.730790</td>
      <td>3109</td>
      <td>3408</td>
      <td>Chaussee d'Antin 8</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093408</td>
      <td>0.082151</td>
    </tr>
    <tr>
      <th>154</th>
      <td>Non</td>
      <td>Couloirs de bus ouverts aux vélos</td>
      <td>9.0</td>
      <td>Sens de circulation générale</td>
      <td>Zone 30</td>
      <td>Rue de la Chaussée d'Antin</td>
      <td>0.013982</td>
      <td>Non</td>
      <td>13.982415</td>
      <td>Niveau chaussée</td>
      <td>None</td>
      <td>2009-12-31</td>
      <td>None</td>
      <td>None</td>
      <td>Traversée de carrefour</td>
      <td>None</td>
      <td>LINESTRING (651020.745 6864130.857, 651024.497...</td>
      <td>13.982415</td>
      <td>3109</td>
      <td>3408</td>
      <td>Chaussee d'Antin 8</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093408</td>
      <td>0.082151</td>
    </tr>
    <tr>
      <th>155</th>
      <td>Non</td>
      <td>Couloirs de bus ouverts aux vélos</td>
      <td>9.0</td>
      <td>Sens de circulation générale</td>
      <td>Zone 30</td>
      <td>Rue de la Chaussée d'Antin</td>
      <td>0.058769</td>
      <td>Non</td>
      <td>58.768555</td>
      <td>None</td>
      <td>None</td>
      <td>2009-12-31</td>
      <td>Marqué</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (651024.497 6864117.388, 651040.269...</td>
      <td>58.768555</td>
      <td>3109</td>
      <td>3408</td>
      <td>Chaussee d'Antin 8</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093408</td>
      <td>0.082151</td>
    </tr>
    <tr>
      <th>768</th>
      <td>Non</td>
      <td>Couloirs de bus ouverts aux vélos</td>
      <td>9.0</td>
      <td>Sens de circulation générale</td>
      <td>Zone 30</td>
      <td>Rue de la Chaussée d'Antin</td>
      <td>0.094016</td>
      <td>Non</td>
      <td>94.016292</td>
      <td>None</td>
      <td>None</td>
      <td>2009-12-31</td>
      <td>Marqué</td>
      <td>None</td>
      <td>None</td>
      <td>None</td>
      <td>LINESTRING (650995.514 6864221.425, 651020.745...</td>
      <td>94.016292</td>
      <td>3109</td>
      <td>3408</td>
      <td>Chaussee d'Antin 8</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093408</td>
      <td>0.082151</td>
    </tr>
    <tr>
      <th>1478</th>
      <td>Non</td>
      <td>Bandes cyclables</td>
      <td>9.0</td>
      <td>Contresens</td>
      <td>Zone de rencontre</td>
      <td>RUE DE PROVENCE</td>
      <td>0.015522</td>
      <td>Non</td>
      <td>15.521966</td>
      <td>None</td>
      <td>None</td>
      <td>2019-12-31</td>
      <td>None</td>
      <td>None</td>
      <td>Traversée de carrefour</td>
      <td>None</td>
      <td>LINESTRING (651047.169 6864015.369, 651048.786...</td>
      <td>15.500707</td>
      <td>3109</td>
      <td>3408</td>
      <td>Chaussee d'Antin 8</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093408</td>
      <td>0.082151</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Calculer la longueur des pistes cyclables par IRIS et en faire une carte

Longueurpistescyclables  = pistescyclablesok[["nom_iris", "longueur"]].groupby("nom_iris").sum()
Longueurpistescyclables =pd.DataFrame(Longueurpistescyclables)
Longueurpistescyclables.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>longueur</th>
    </tr>
    <tr>
      <th>nom_iris</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Amerique 1</th>
      <td>2003.132358</td>
    </tr>
    <tr>
      <th>Amerique 10</th>
      <td>1162.361189</td>
    </tr>
    <tr>
      <th>Amerique 11</th>
      <td>1295.051080</td>
    </tr>
    <tr>
      <th>Amerique 12</th>
      <td>829.970593</td>
    </tr>
    <tr>
      <th>Amerique 13</th>
      <td>958.983086</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Verification somme

total1 = pistescyclablesok['longueur'].sum()
total2 = Longueurpistescyclables['longueur'].sum()

print(total1)
print(total2)
```

    1671662.7310180047
    1671662.731018005
    


```python
# Faire la jointure attributaire

IRISfinal = IRISPARIS.merge(Longueurpistescyclables, left_on='nom_iris', right_on='nom_iris')
IRISfinal.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>longueur</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((2.35084 48.86334, 2.35095 48.86340, ...</td>
      <td>5445.670909</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((2.36789 48.85827, 2.36811 48.85739, ...</td>
      <td>405.046514</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POLYGON ((2.35855 48.85022, 2.35757 48.85056, ...</td>
      <td>2771.445339</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((2.35166 48.84660, 2.35279 48.84595, ...</td>
      <td>275.943463</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((2.33699 48.85387, 2.33692 48.85452, ...</td>
      <td>890.350957</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Cartographier la capacité des stations de vélibs par IRIS

Carte2, ax = plt.subplots(figsize=(18,16))
IRISPARIS.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.1, color = 'black')
IRISfinal.to_crs('EPSG:3857').plot(ax=ax, column="longueur", alpha=1, cmap='Blues',scheme='quantiles', categorical=False, legend=True)
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```


![png](output_34_0.png)


## Exporter des couches dans différents formats



```python
# Exporter des couches

## En shapefile

IRISbis.to_file("IRISbis.shp")

## En GEOJSON

IRISbis.to_file("IRISbis.geojson", driver='GeoJSON')

## En Geopackage (pour combiner plusieurs couches)

IRISbis.to_file("Paris.gpkg", layer='countries', driver="GPKG")
Velibok.to_file("Paris.gpkg", layer='cities', driver="GPKG")
```

## EXERCICE AUTOUR DES ARBRES

* Ne garder que les arbres de Paris
* Compter le nombre d'arbres par IRIS (jointure spatiale puis agrégations statistique)
* Verifier les sommes
* Calculer la hauteur moyenne des arbres par IRIS
* Faire la jointure attibutaire vers la couches des IRIS
* Faire une carte du nombre d'arbres par IRIS
* Faire une carte avec les hauteurs moyennes des arbres par IRIS


```python
#Téléchargement des datas depuis le portail opendata
!wget -O arbres.csv https://opendata.paris.fr/explore/dataset/les-arbres/download/?format=csv&timezone=Europe/Berlin&lang=fr&use_labels_for_header=true&csv_separator=%3B 
```


```python
#Importer CSV to dataframe

arbres = pd.read_csv("arbres.csv", sep=';')
arbres.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>typeemplacement</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>complementadresse</th>
      <th>numero</th>
      <th>adresse</th>
      <th>idemplacement</th>
      <th>libellefrancais</th>
      <th>genre</th>
      <th>espece</th>
      <th>varieteoucultivar</th>
      <th>circonferenceencm</th>
      <th>hauteurenm</th>
      <th>stadedeveloppement</th>
      <th>remarquable</th>
      <th>geo_point_2d</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>Arbre</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>CENTRE SPORTIF JULES LADOUMEGUE / 35 ROUTE DES...</td>
      <td>000104004</td>
      <td>Copalme</td>
      <td>Liquidambar</td>
      <td>styraciflua</td>
      <td>NaN</td>
      <td>20</td>
      <td>5</td>
      <td>J</td>
      <td>NON</td>
      <td>48.8910678703,2.39818911237</td>
    </tr>
    <tr>
      <th>1</th>
      <td>251547</td>
      <td>Arbre</td>
      <td>Alignement</td>
      <td>PARIS 16E ARRDT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AVENUE DU PRESIDENT WILSON</td>
      <td>000303003</td>
      <td>Platane</td>
      <td>Platanus</td>
      <td>x hispanica</td>
      <td>NaN</td>
      <td>205</td>
      <td>20</td>
      <td>A</td>
      <td>NON</td>
      <td>48.8649086201,2.2993502247</td>
    </tr>
    <tr>
      <th>2</th>
      <td>282670</td>
      <td>Arbre</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>AVENUE PERCIER</td>
      <td>000202005</td>
      <td>Platane</td>
      <td>Platanus</td>
      <td>x hispanica</td>
      <td>NaN</td>
      <td>86</td>
      <td>12</td>
      <td>A</td>
      <td>NON</td>
      <td>48.8740816418,2.31454494358</td>
    </tr>
    <tr>
      <th>3</th>
      <td>185672</td>
      <td>Arbre</td>
      <td>DASCO</td>
      <td>PARIS 20E ARRDT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>ECOLE ELEMENTAIRE / 24 RUE OLIVIER METRA</td>
      <td>098501015</td>
      <td>Bouleau</td>
      <td>Betula</td>
      <td>pendula</td>
      <td>NaN</td>
      <td>75</td>
      <td>12</td>
      <td>J</td>
      <td>NON</td>
      <td>48.8732579515,2.3942408403</td>
    </tr>
    <tr>
      <th>4</th>
      <td>219422</td>
      <td>Arbre</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>BOULEVARD HAUSSMANN</td>
      <td>003202007</td>
      <td>Platane</td>
      <td>Platanus</td>
      <td>x hispanica</td>
      <td>NaN</td>
      <td>54</td>
      <td>9</td>
      <td>A</td>
      <td>NON</td>
      <td>48.8751388795,2.31742365137</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Réorganiser la table

arbresok = arbres[["idbase", "domanialite", "arrondissement", "libellefrancais", "hauteurenm", "geo_point_2d"]]
arbresok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
    </tr>
    <tr>
      <th>1</th>
      <td>251547</td>
      <td>Alignement</td>
      <td>PARIS 16E ARRDT</td>
      <td>Platane</td>
      <td>20</td>
      <td>48.8649086201,2.2993502247</td>
    </tr>
    <tr>
      <th>2</th>
      <td>282670</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>Platane</td>
      <td>12</td>
      <td>48.8740816418,2.31454494358</td>
    </tr>
    <tr>
      <th>3</th>
      <td>185672</td>
      <td>DASCO</td>
      <td>PARIS 20E ARRDT</td>
      <td>Bouleau</td>
      <td>12</td>
      <td>48.8732579515,2.3942408403</td>
    </tr>
    <tr>
      <th>4</th>
      <td>219422</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>Platane</td>
      <td>9</td>
      <td>48.8751388795,2.31742365137</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Séparer la colonne des coordonnées géographiques

arbresok[['Latitude','Longitude']] = arbresok['geo_point_2d'].str.split(',', expand=True)
arbresok.head()
```

    /usr/local/lib/python3.7/dist-packages/pandas/core/frame.py:3069: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      self[k1] = value[k2]
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
      <th>Latitude</th>
      <th>Longitude</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
      <td>48.8910678703</td>
      <td>2.39818911237</td>
    </tr>
    <tr>
      <th>1</th>
      <td>251547</td>
      <td>Alignement</td>
      <td>PARIS 16E ARRDT</td>
      <td>Platane</td>
      <td>20</td>
      <td>48.8649086201,2.2993502247</td>
      <td>48.8649086201</td>
      <td>2.2993502247</td>
    </tr>
    <tr>
      <th>2</th>
      <td>282670</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>Platane</td>
      <td>12</td>
      <td>48.8740816418,2.31454494358</td>
      <td>48.8740816418</td>
      <td>2.31454494358</td>
    </tr>
    <tr>
      <th>3</th>
      <td>185672</td>
      <td>DASCO</td>
      <td>PARIS 20E ARRDT</td>
      <td>Bouleau</td>
      <td>12</td>
      <td>48.8732579515,2.3942408403</td>
      <td>48.8732579515</td>
      <td>2.3942408403</td>
    </tr>
    <tr>
      <th>4</th>
      <td>219422</td>
      <td>Alignement</td>
      <td>PARIS 8E ARRDT</td>
      <td>Platane</td>
      <td>9</td>
      <td>48.8751388795,2.31742365137</td>
      <td>48.8751388795</td>
      <td>2.31742365137</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Dataframe to GeoDataframe

arbresok = gpd.GeoDataFrame(arbresok, crs = 'epsg:4326', geometry=gpd.points_from_xy(arbresok.Longitude, arbresok.Latitude))
arbresok.crs
```




    <Geographic 2D CRS: EPSG:4326>
    Name: WGS 84
    Axis Info [ellipsoidal]:
    - Lat[north]: Geodetic latitude (degree)
    - Lon[east]: Geodetic longitude (degree)
    Area of Use:
    - name: World.
    - bounds: (-180.0, -90.0, 180.0, 90.0)
    Datum: World Geodetic System 1984
    - Ellipsoid: WGS 84
    - Prime Meridian: Greenwich




```python
#Ne garder que les arbres de la ville de Paris (environ 60 secondes sans index spatial)

ArbresParis = gpd.overlay(arbresok, IRISPARIS, how='intersection')
ArbresParis.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
      <td>48.8910678703</td>
      <td>2.39818911237</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39819 48.89107)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>195778</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>8</td>
      <td>48.9001235785,2.38322501988</td>
      <td>48.9001235785</td>
      <td>2.38322501988</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38323 48.90012)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>244721</td>
      <td>Alignement</td>
      <td>PARIS 19E ARRDT</td>
      <td>Sophora</td>
      <td>10</td>
      <td>48.8935066484,2.39475564106</td>
      <td>48.8935066484</td>
      <td>2.39475564106</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39476 48.89351)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>195777</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>5</td>
      <td>48.9001335481,2.3832976338</td>
      <td>48.9001335481</td>
      <td>2.3832976338</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38330 48.90013)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>114747</td>
      <td>Jardin</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>5</td>
      <td>48.8997005285,2.39157031289</td>
      <td>48.8997005285</td>
      <td>2.39157031289</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39157 48.89970)</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Jointure spatiale Arbres <> IRIS

arbresok = gpd.sjoin(ArbresParis, IRISPARIS)
arbresok.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>iris_left</th>
      <th>nom_iris_left</th>
      <th>typ_iris_left</th>
      <th>dep_left</th>
      <th>insee_com_left</th>
      <th>nom_com_left</th>
      <th>code_iris_left</th>
      <th>geometry</th>
      <th>index_right</th>
      <th>iris_right</th>
      <th>nom_iris_right</th>
      <th>typ_iris_right</th>
      <th>dep_right</th>
      <th>insee_com_right</th>
      <th>nom_com_right</th>
      <th>code_iris_right</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
      <td>48.8910678703</td>
      <td>2.39818911237</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39819 48.89107)</td>
      <td>4964</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
    </tr>
    <tr>
      <th>1</th>
      <td>195778</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>8</td>
      <td>48.9001235785,2.38322501988</td>
      <td>48.9001235785</td>
      <td>2.38322501988</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38323 48.90012)</td>
      <td>4964</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
    </tr>
    <tr>
      <th>2</th>
      <td>244721</td>
      <td>Alignement</td>
      <td>PARIS 19E ARRDT</td>
      <td>Sophora</td>
      <td>10</td>
      <td>48.8935066484,2.39475564106</td>
      <td>48.8935066484</td>
      <td>2.39475564106</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39476 48.89351)</td>
      <td>4964</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
    </tr>
    <tr>
      <th>3</th>
      <td>195777</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>5</td>
      <td>48.9001335481,2.3832976338</td>
      <td>48.9001335481</td>
      <td>2.3832976338</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38330 48.90013)</td>
      <td>4964</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
    </tr>
    <tr>
      <th>4</th>
      <td>114747</td>
      <td>Jardin</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>5</td>
      <td>48.8997005285,2.39157031289</td>
      <td>48.8997005285</td>
      <td>2.39157031289</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39157 48.89970)</td>
      <td>4964</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Compter le nombre d'arbres par IRIS

NbArbres  = arbresok[["code_iris_left", "idbase"]].groupby("code_iris_left").size()
NbArbres =pd.DataFrame(NbArbres)
NbArbres = NbArbres.rename(columns={0: 'NbArbres'})
NbArbres.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>NbArbres</th>
    </tr>
    <tr>
      <th>code_iris_left</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>751010101</th>
      <td>123</td>
    </tr>
    <tr>
      <th>751010102</th>
      <td>76</td>
    </tr>
    <tr>
      <th>751010103</th>
      <td>45</td>
    </tr>
    <tr>
      <th>751010199</th>
      <td>458</td>
    </tr>
    <tr>
      <th>751010201</th>
      <td>159</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Verification somme

total1 = ArbresParis['domanialite'].size
total2 = NbArbres['NbArbres'].sum()

print(total1)
print(total2)
```

    178735
    178735
    


```python
# Faire la jointure attributaire

IRISbis = IRISPARIS.merge(NbArbres, left_on='code_iris', right_on='code_iris_left')
IRISbis.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>NbArbres</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((2.35084 48.86334, 2.35095 48.86340, ...</td>
      <td>60</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((2.36789 48.85827, 2.36811 48.85739, ...</td>
      <td>66</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POLYGON ((2.35855 48.85022, 2.35757 48.85056, ...</td>
      <td>30</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((2.35166 48.84660, 2.35279 48.84595, ...</td>
      <td>157</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((2.33699 48.85387, 2.33692 48.85452, ...</td>
      <td>17</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Calculer la hauteur moyenne des arbres par IRIS

Hauteurmoyenne = arbresok[["code_iris_left", "hauteurenm"]].groupby("code_iris_left").mean()
Hauteurmoyenne.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>hauteurenm</th>
    </tr>
    <tr>
      <th>code_iris_left</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>751010101</th>
      <td>10.691057</td>
    </tr>
    <tr>
      <th>751010102</th>
      <td>9.250000</td>
    </tr>
    <tr>
      <th>751010103</th>
      <td>6.977778</td>
    </tr>
    <tr>
      <th>751010199</th>
      <td>10.777293</td>
    </tr>
    <tr>
      <th>751010201</th>
      <td>6.591195</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Faire la jointure attributaire

IRISfinal = IRISbis.merge(Hauteurmoyenne, left_on='code_iris', right_on='code_iris_left')
IRISfinal.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>NbArbres</th>
      <th>hauteurenm</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1203</td>
      <td>Sainte-Avoye 3</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031203</td>
      <td>POLYGON ((2.35084 48.86334, 2.35095 48.86340, ...</td>
      <td>60</td>
      <td>9.683333</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1102</td>
      <td>Les Archives 2</td>
      <td>H</td>
      <td>75</td>
      <td>75103</td>
      <td>Paris 3e Arrondissement</td>
      <td>751031102</td>
      <td>POLYGON ((2.36789 48.85827, 2.36811 48.85739, ...</td>
      <td>66</td>
      <td>11.257576</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1601</td>
      <td>Notre Dame 1</td>
      <td>H</td>
      <td>75</td>
      <td>75104</td>
      <td>Paris 4e Arrondissement</td>
      <td>751041601</td>
      <td>POLYGON ((2.35855 48.85022, 2.35757 48.85056, ...</td>
      <td>30</td>
      <td>7.766667</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1702</td>
      <td>Saint-Victor 2</td>
      <td>H</td>
      <td>75</td>
      <td>75105</td>
      <td>Paris 5e Arrondissement</td>
      <td>751051702</td>
      <td>POLYGON ((2.35166 48.84660, 2.35279 48.84595, ...</td>
      <td>157</td>
      <td>8.445860</td>
    </tr>
    <tr>
      <th>4</th>
      <td>2102</td>
      <td>Monnaie 2</td>
      <td>H</td>
      <td>75</td>
      <td>75106</td>
      <td>Paris 6e Arrondissement</td>
      <td>751062102</td>
      <td>POLYGON ((2.33699 48.85387, 2.33692 48.85452, ...</td>
      <td>17</td>
      <td>7.176471</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Cartographier le nombre d'arbres par IRIS
IRISfinalcentro = IRISfinal.copy()
IRISfinalcentro.geometry = IRISfinalcentro['geometry'].centroid

Cartenbarbres, ax = plt.subplots(figsize=(18,16))
ARDT.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.8, color = 'black')
IRISPARIS.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.1, color = 'black')
IRISfinalcentro.to_crs('EPSG:3857').plot(ax=ax, markersize="NbArbres", alpha=0.8, cmap='Greens',scheme='quantiles', categorical=False, legend=True)
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
plt.title("Nombre d'arbres par IRIS /Ville de Paris", loc='left', fontsize=20)
ax.axis("off")
plt.show()
```

    /usr/local/lib/python3.7/dist-packages/ipykernel_launcher.py:3: UserWarning: Geometry is in a geographic CRS. Results from 'centroid' are likely incorrect. Use 'GeoSeries.to_crs()' to re-project geometries to a projected CRS before this operation.
    
      This is separate from the ipykernel package so we can avoid doing imports until
    


![png](output_51_1.png)



```python
#Cartographier la hauteur moyenne des arbres par IRIS

Cartehauteur, ax = plt.subplots(figsize=(18,16))
ARDT.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.8, color = 'black')
IRISPARIS.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.1, color = 'black')
IRISfinal.to_crs('EPSG:3857').plot(ax=ax, k=7, column="hauteurenm", alpha=1, cmap='YlGn',scheme='quantiles', categorical=False, legend=True)
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
plt.title("Hauteur moyenne des arbres par IRIS / Ville de Paris", loc='left', fontsize=20)
ax.axis("off")
plt.show()
```


![png](output_52_0.png)


## Buffer, Intersection, difference...





```python
#Importer la couche des arrêts de TC

ArretsTC= gpd.read_file("ArretsTC.geojson", encoding='utf-8')
ArretsTC.plot()
ArretsTC.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>POINT (2.29557 48.87461)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>8.0</td>
      <td>Havre-Caumartin</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58718.0</td>
      <td>0</td>
      <td>344</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 3</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>3-103061</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Havre-Caumartin</td>
      <td>0</td>
      <td>6.863931e+06</td>
      <td>3</td>
      <td>2060</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>73688</td>
      <td>Metro</td>
      <td>HAVRE-CAUMARTIN</td>
      <td>C01373</td>
      <td>650675.9316</td>
      <td>A01536</td>
      <td>POINT (2.32754 48.87351)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>11.0</td>
      <td>Gare d'Austerlitz</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>43072.0</td>
      <td>0</td>
      <td>312</td>
      <td>1</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 5</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>5-375</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Gare d'Austerlitz</td>
      <td>0</td>
      <td>6.860434e+06</td>
      <td>5</td>
      <td>2104</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>5</td>
      <td>71135</td>
      <td>Metro</td>
      <td>AUSTERLITZ</td>
      <td>C01375</td>
      <td>653420.2120</td>
      <td>A01538</td>
      <td>POINT (2.36534 48.84227)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>13.0</td>
      <td>Gare de l'Est</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>43138.0</td>
      <td>0</td>
      <td>315</td>
      <td>1</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 7</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>7-327</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Gare de l'Est</td>
      <td>0</td>
      <td>6.864219e+06</td>
      <td>7</td>
      <td>2178</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>7</td>
      <td>71359</td>
      <td>Metro</td>
      <td>GARE DE L'EST</td>
      <td>C01377</td>
      <td>652916.6085</td>
      <td>A01540</td>
      <td>POINT (2.35806 48.87627)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>5.0</td>
      <td>Montparnasse Bienvenüe</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>43238.0</td>
      <td>0</td>
      <td>563</td>
      <td>1</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 13</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>13-285</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Montparnasse-Bienvenüe</td>
      <td>0</td>
      <td>6.860468e+06</td>
      <td>13</td>
      <td>2334</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>13</td>
      <td>71139</td>
      <td>Metro</td>
      <td>MONTPARNASSE</td>
      <td>C01383</td>
      <td>650165.0831</td>
      <td>A01546</td>
      <td>POINT (2.32098 48.84233)</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_54_1.png)



```python
# Ne garder que les arrêts de métro de Paris

Metros = ArretsTC[(ArretsTC["mode"] == 'Metro')]
Metros = gpd.overlay(Metros, IRISPARIS, how='intersection')
Metros.plot(column='res_com')
Metros.head()

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (2.29557 48.87461)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>12.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>154</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 6</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>6-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>M6</td>
      <td>6.864089e+06</td>
      <td>6</td>
      <td>2150</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01376</td>
      <td>648331.3084</td>
      <td>A01539</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (2.29556 48.87475)</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>152</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 1</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>1-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles De Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864133e+06</td>
      <td>1</td>
      <td>2006</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01371</td>
      <td>648356.9846</td>
      <td>A01534</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (2.29590 48.87515)</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>8.0</td>
      <td>Havre-Caumartin</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58718.0</td>
      <td>0</td>
      <td>344</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 3</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>3-103061</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Havre-Caumartin</td>
      <td>0</td>
      <td>6.863931e+06</td>
      <td>3</td>
      <td>2060</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>73688</td>
      <td>Metro</td>
      <td>HAVRE-CAUMARTIN</td>
      <td>C01373</td>
      <td>650675.9316</td>
      <td>A01536</td>
      <td>3403</td>
      <td>Chaussee d'Antin 3</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093403</td>
      <td>POINT (2.32754 48.87351)</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>15.0</td>
      <td>Madeleine</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>43898.0</td>
      <td>0</td>
      <td>489</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 8</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>8-108039</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Madeleine</td>
      <td>0</td>
      <td>6.863500e+06</td>
      <td>8</td>
      <td>2215</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>8</td>
      <td>71324</td>
      <td>Metro</td>
      <td>MADELEINE</td>
      <td>C01378</td>
      <td>650579.0401</td>
      <td>A01541</td>
      <td>3403</td>
      <td>Chaussee d'Antin 3</td>
      <td>A</td>
      <td>75</td>
      <td>75109</td>
      <td>Paris 9e Arrondissement</td>
      <td>751093403</td>
      <td>POINT (2.32627 48.86963)</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_55_1.png)



```python
# Reprojeter la couche des arrêts de métro 

Metros = Metros.to_crs(2154)
Metros.crs
```




    <Projected CRS: EPSG:2154>
    Name: RGF93 / Lambert-93
    Axis Info [cartesian]:
    - X[east]: Easting (metre)
    - Y[north]: Northing (metre)
    Area of Use:
    - name: France - onshore and offshore, mainland and Corsica.
    - bounds: (-9.86, 41.15, 10.38, 51.56)
    Coordinate Operation:
    - name: Lambert-93
    - method: Lambert Conic Conformal (2SP)
    Datum: Reseau Geodesique Francais 1993
    - Ellipsoid: GRS 1980
    - Prime Meridian: Greenwich




```python
# Buffer de 400m autour des métros

Metrosbuffer = Metros.copy()
Metrosbuffer['geometry'] = Metrosbuffer.geometry.buffer(400)
Metrosbuffer.plot(figsize=(10,10))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdfa98a790>




![png](output_57_1.png)



```python
# Reprojeter la couche des vélibs

VelibParis2154 = VelibParis.to_crs(2154)
VelibParis2154.crs
```




    <Projected CRS: EPSG:2154>
    Name: RGF93 / Lambert-93
    Axis Info [cartesian]:
    - X[east]: Easting (metre)
    - Y[north]: Northing (metre)
    Area of Use:
    - name: France - onshore and offshore, mainland and Corsica.
    - bounds: (-9.86, 41.15, 10.38, 51.56)
    Coordinate Operation:
    - name: Lambert-93
    - method: Lambert Conic Conformal (2SP)
    Datum: Reseau Geodesique Francais 1993
    - Ellipsoid: GRS 1980
    - Prime Meridian: Greenwich




```python
# Buffer de 200m autour des vélibs

Velibsbuffer = VelibParis2154.copy()
Velibsbuffer['geometry'] = Velibsbuffer.geometry.buffer(200)
Velibsbuffer.plot(figsize=(10,10))
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdf9dbbe50>




![png](output_59_1.png)



```python
# INTERSECTION des zones à moins de 400m d'une station de métro et à moins de 200m d'une station de vélibs

Intersect = gpd.overlay(Metrosbuffer, Velibsbuffer, how='intersection')

MapIntersect, ax = plt.subplots(figsize=(10,10))
Intersect.to_crs('EPSG:3857').plot(ax=ax, alpha=0.8,)
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```


![png](output_60_0.png)



```python
# DIFFERENCE des zones tampons de buffer par les zones tampons des vélibs

Difference = gpd.overlay(Metrosbuffer, Velibsbuffer, how='difference')

MapDifference, ax = plt.subplots(figsize=(10,10))
Difference.to_crs('EPSG:3857').plot(ax=ax, alpha=0.6,)
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```


![png](output_61_0.png)



```python
# UNION des zones tampons des métros et des vélibs

Union = gpd.overlay(Metrosbuffer, Velibsbuffer, how='union')

MapUnion, ax = plt.subplots(figsize=(10,10))
Union.to_crs('EPSG:3857').plot(ax=ax, alpha=0.6,)
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```


![png](output_62_0.png)


## Analyse du plus proche voisin


```python
# Ne garder que les arrêts de RER de paris
RER = ArretsTC[(ArretsTC["mode"] == 'RER')]
RER = gpd.overlay(RER, IRISPARIS, how='intersection')

RER = RER.to_crs(2154)

RER.plot(column='res_com')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdfa7f8150>




![png](output_64_1.png)



```python
# Affichage des stations de métro 
Metros.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdf8f146d0>




![png](output_65_1.png)



```python
#Calcul des distances

from shapely.geometry import Point, MultiPoint
from shapely.ops import nearest_points

def get_nearest_values(row, other_gdf, point_column='geometry', value_column="geometry"):
    
    # Create an union of the other GeoDataFrame's geometries:
    other_points = other_gdf["geometry"].unary_union
    
    # Find the nearest points
    nearest_geoms = nearest_points(row[point_column], other_points)
    
    # Get corresponding values from the other df
    nearest_data = other_gdf.loc[other_gdf["geometry"] == nearest_geoms[1]]
    
    nearest_value = nearest_data[value_column].values[0]
    
    return nearest_value
```


```python
#Union des RER

unary_union = RER.unary_union
```


```python
#Ajouter une colonne avec les coordonnées de la gare RER la plus proche

Metros["nearest_loc"] = Metros.apply(get_nearest_values, other_gdf=RER, axis=1)
Metros.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.696 6864073.835)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>12.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>154</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 6</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>6-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>M6</td>
      <td>6.864089e+06</td>
      <td>6</td>
      <td>2150</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01376</td>
      <td>648331.3084</td>
      <td>A01539</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.308 6864088.819)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Ajouter une colonne avec le nom de la gare RER la plus proche

Metros["nearest_stations"] = Metros.apply(get_nearest_values, other_gdf=RER, value_column="nom_iv", axis=1)
Metros.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.696 6864073.835)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>12.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>154</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 6</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>6-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>M6</td>
      <td>6.864089e+06</td>
      <td>6</td>
      <td>2150</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01376</td>
      <td>648331.3084</td>
      <td>A01539</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.308 6864088.819)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Créer une nouvelle colonne de géométrie à partir des couples de coordonnées

from shapely.geometry import LineString

Metros['line'] = Metros.apply(lambda row: LineString([row['geometry'], row['nearest_loc']]), axis=1)# Create Line Geodataframe
line_gdf = Metros[["nom_iv", "nearest_stations", "line"]].set_geometry('line')# Set the Coordinate reference
line_gdf.crs = crs={"init":"epsg:2154"}
Metros.head(3)
```

    /usr/local/lib/python3.7/dist-packages/pyproj/crs/crs.py:53: FutureWarning: '+init=<authority>:<code>' syntax is deprecated. '<authority>:<code>' is the preferred initialization method. When making the change, be mindful of axis order changes: https://pyproj4.github.io/pyproj/stable/gotchas.html#axis-order-changes-in-proj-6
      return _prepare_from_string(" ".join(pjargs))
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
      <th>line</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.696 6864073.835)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648331.6964999898 6864073.83459848...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>12.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>154</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 6</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>6-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>M6</td>
      <td>6.864089e+06</td>
      <td>6</td>
      <td>2150</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01376</td>
      <td>648331.3084</td>
      <td>A01539</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.308 6864088.819)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648331.308399984 6864088.819498481...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>152</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 1</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>1-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles De Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864133e+06</td>
      <td>1</td>
      <td>2006</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01371</td>
      <td>648356.9846</td>
      <td>A01534</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648356.985 6864133.201)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648356.9845999865 6864133.20099848...</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Générer une nouvelle couche de lignes

LinkMetroRer = Metros.copy()
LinkMetroRer = LinkMetroRer.set_geometry('line')
LinkMetroRer.plot(figsize =(10,10), column = 'nearest_stations')
LinkMetroRer.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tertrain</th>
      <th>cod_ligf</th>
      <th>nom_iv</th>
      <th>res_stif</th>
      <th>cod_resf</th>
      <th>tertram</th>
      <th>id_ref_zdl</th>
      <th>navette</th>
      <th>gares_id</th>
      <th>principal</th>
      <th>reseau</th>
      <th>val</th>
      <th>res_com</th>
      <th>rer</th>
      <th>ternavette</th>
      <th>picto</th>
      <th>ligne_code</th>
      <th>fer</th>
      <th>terrer</th>
      <th>num_psr</th>
      <th>nom_gare</th>
      <th>termetro</th>
      <th>y</th>
      <th>ligne</th>
      <th>num_mod</th>
      <th>idf</th>
      <th>terfer</th>
      <th>train</th>
      <th>tramway</th>
      <th>exploitant</th>
      <th>metro</th>
      <th>terval</th>
      <th>indice_lig</th>
      <th>id_ref_lda</th>
      <th>mode</th>
      <th>nomlong</th>
      <th>idrefligc</th>
      <th>x</th>
      <th>idrefliga</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
      <th>line</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>7.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>153</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 2</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>2-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864074e+06</td>
      <td>2</td>
      <td>2047</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01372</td>
      <td>648331.6965</td>
      <td>A01535</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.696 6864073.835)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648331.696 6864073.835, 648252.347...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>12.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>154</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 6</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>6-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles de Gaulle-Étoile</td>
      <td>M6</td>
      <td>6.864089e+06</td>
      <td>6</td>
      <td>2150</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>6</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01376</td>
      <td>648331.3084</td>
      <td>A01539</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648331.308 6864088.819)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648331.308 6864088.819, 648252.347...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>1.0</td>
      <td>Charles de Gaulle Etoile</td>
      <td>110.0</td>
      <td>3.0</td>
      <td>0</td>
      <td>58759.0</td>
      <td>0</td>
      <td>152</td>
      <td>0</td>
      <td>METRO</td>
      <td>0</td>
      <td>METRO 1</td>
      <td>0</td>
      <td>0</td>
      <td>{'mimetype': 'image/svg+xml', 'format': 'svg',...</td>
      <td>1-337</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>Charles De Gaulle-Étoile</td>
      <td>0</td>
      <td>6.864133e+06</td>
      <td>1</td>
      <td>2006</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>RATP</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>71347</td>
      <td>Metro</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>C01371</td>
      <td>648356.9846</td>
      <td>A01534</td>
      <td>6501</td>
      <td>Ternes 1</td>
      <td>H</td>
      <td>75</td>
      <td>75117</td>
      <td>Paris 17e Arrondissement</td>
      <td>751176501</td>
      <td>POINT (648356.985 6864133.201)</td>
      <td>POINT (648252.346799986 6864032.792498482)</td>
      <td>CHARLES DE GAULLE ETOILE</td>
      <td>LINESTRING (648356.985 6864133.201, 648252.347...</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_71_1.png)



```python
#Faire une carte

Carteflux1, ax = plt.subplots(figsize=(18,16))
RER.to_crs('EPSG:3857').plot(ax=ax, markersize = 50, column = 'nom_iv')
LinkMetroRer.to_crs('EPSG:3857').plot(ax=ax, column = 'nearest_stations', linewidth=1)
Metros.to_crs('EPSG:3857').plot(ax=ax, markersize = 10, column = 'nearest_stations')
ARDT.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.7, color = 'grey')
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
ax.axis("off")
plt.show()
```


![png](output_72_0.png)


## Exercice sur la proximité des stations de vélibs aux stations de métro


```python
# Affichage des stations de vélibs 
VelibParis2154.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdf913f9d0>




![png](output_74_1.png)



```python
# Affichage des stations de métro 
Metros.plot()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x7fcdf8f146d0>




![png](output_75_1.png)



```python
#Calcul des distances

from shapely.geometry import Point, MultiPoint
from shapely.ops import nearest_points

def get_nearest_values(row, other_gdf, point_column='geometry', value_column="geometry"):
    
    # Create an union of the other GeoDataFrame's geometries:
    other_points = other_gdf["geometry"].unary_union
    
    # Find the nearest points
    nearest_geoms = nearest_points(row[point_column], other_points)
    
    # Get corresponding values from the other df
    nearest_data = other_gdf.loc[other_gdf["geometry"] == nearest_geoms[1]]
    
    nearest_value = nearest_data[value_column].values[0]
    
    return nearest_value
```


```python
#Union des stations de métros

unary_union = Metros.unary_union
```


```python
#Ajouter une colonne dans la couche des vélibs avec les coordonnées de la station de métro la plus proche et une autre colonne avec le nom de la station de métro

VelibParis2154["nearest_loc"] = VelibParis2154.apply(get_nearest_values, other_gdf=Metros, axis=1)
VelibParis2154["nearest_stations"] = VelibParis2154.apply(get_nearest_values, other_gdf=Metros, value_column="nom_iv", axis=1)
VelibParis2154.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>8</td>
      <td>3</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>26</td>
      <td>2021-03-04T12:34:56+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646867.548 6863127.314)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>18</td>
      <td>Flandrin - Henri Martin</td>
      <td>Paris</td>
      <td>6</td>
      <td>3</td>
      <td>16018</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>12</td>
      <td>2021-03-04T12:43:11+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646623.214 6862945.467)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Créer une nouvelle colonne de géométrie à partir des couples de coordonnées

from shapely.geometry import LineString

VelibParis2154['line'] = VelibParis2154.apply(lambda row: LineString([row['geometry'], row['nearest_loc']]), axis=1)# Create Line Geodataframe
line_gdf = VelibParis2154[["stationcode", "nearest_stations", "line"]].set_geometry('line')# Set the Coordinate reference
line_gdf.crs = crs={"init":"epsg:2154"}
VelibParis2154.head(3)
```

    /usr/local/lib/python3.7/dist-packages/pyproj/crs/crs.py:53: FutureWarning: '+init=<authority>:<code>' syntax is deprecated. '<authority>:<code>' is the preferred initialization method. When making the change, be mindful of axis order changes: https://pyproj4.github.io/pyproj/stable/gotchas.html#axis-order-changes-in-proj-6
      return _prepare_from_string(" ".join(pjargs))
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
      <th>line</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>8</td>
      <td>3</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>26</td>
      <td>2021-03-04T12:34:56+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646867.548 6863127.314)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
      <td>LINESTRING (646867.5475999101 6863127.31356447...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>18</td>
      <td>Flandrin - Henri Martin</td>
      <td>Paris</td>
      <td>6</td>
      <td>3</td>
      <td>16018</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>12</td>
      <td>2021-03-04T12:43:11+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646623.214 6862945.467)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
      <td>LINESTRING (646623.214381445 6862945.467321204...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>20</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>Paris</td>
      <td>2</td>
      <td>1</td>
      <td>11104</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>18</td>
      <td>2021-03-04T12:44:23+00:00</td>
      <td>OUI</td>
      <td>4411</td>
      <td>Sainte-Marguerite 11</td>
      <td>H</td>
      <td>75</td>
      <td>75111</td>
      <td>Paris 11e Arrondissement</td>
      <td>751114411</td>
      <td>POINT (655430.484 6861934.722)</td>
      <td>POINT (655576.9893999876 6861985.837598477)</td>
      <td>Alexandre Dumas</td>
      <td>LINESTRING (655430.4842862445 6861934.72171558...</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Générer une nouvelle couche de lignes

LinkVelibsMetro = VelibParis2154.copy()
LinkVelibsMetro = LinkVelibsMetro.set_geometry('line')
LinkVelibsMetro.plot(figsize =(10,10), column = 'nearest_stations')
LinkVelibsMetro.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>nearest_loc</th>
      <th>nearest_stations</th>
      <th>line</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>8</td>
      <td>3</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>26</td>
      <td>2021-03-04T12:34:56+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646867.548 6863127.314)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
      <td>LINESTRING (646867.548 6863127.314, 647040.651...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>18</td>
      <td>Flandrin - Henri Martin</td>
      <td>Paris</td>
      <td>6</td>
      <td>3</td>
      <td>16018</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>12</td>
      <td>2021-03-04T12:43:11+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (646623.214 6862945.467)</td>
      <td>POINT (647040.6509999866 6862902.376098479)</td>
      <td>Rue de la Pompe</td>
      <td>LINESTRING (646623.214 6862945.467, 647040.651...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>20</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>Paris</td>
      <td>2</td>
      <td>1</td>
      <td>11104</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>18</td>
      <td>2021-03-04T12:44:23+00:00</td>
      <td>OUI</td>
      <td>4411</td>
      <td>Sainte-Marguerite 11</td>
      <td>H</td>
      <td>75</td>
      <td>75111</td>
      <td>Paris 11e Arrondissement</td>
      <td>751114411</td>
      <td>POINT (655430.484 6861934.722)</td>
      <td>POINT (655576.9893999876 6861985.837598477)</td>
      <td>Alexandre Dumas</td>
      <td>LINESTRING (655430.484 6861934.722, 655576.989...</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_80_1.png)



```python
#Faire une carte

Carteflux2, ax = plt.subplots(figsize=(18,16))
Metros.to_crs('EPSG:3857').plot(ax=ax, markersize = 10, column = 'nearest_stations')
LinkVelibsMetro.to_crs('EPSG:3857').plot(ax=ax, column = 'nearest_stations', linewidth=1)
VelibParis2154.to_crs('EPSG:3857').plot(ax=ax, markersize = 1, color = 'white')
ARDT.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=0.7, color = 'white', alpha=0.7)
ax.axis("off")
ctx.add_basemap(ax, source=ctx.providers.CartoDB.DarkMatterNoLabels)
plt.show()
```


![png](output_81_0.png)


## Carroyage

### Méthode 1 > Carroyage "manuel"

####Nombre de places de vélibs 


```python
 VelibParis.total_bounds
```




    array([ 644304.428499  , 6857550.11859008,  660405.2041406 ,
           6866949.75249712])




```python
# Définir l'emprise de la grille
xmin, ymin, xmax, ymax= VelibParis.total_bounds

# Paramètrer le nombre de cellule
n_cells=30
cell_size = (xmax-xmin)/n_cells

# Création des cellules
grid_cells = []
for x0 in np.arange(xmin, xmax+cell_size, cell_size ):
    for y0 in np.arange(ymin, ymax+cell_size, cell_size):
        # bounds
        x1 = x0-cell_size
        y1 = y0+cell_size
        grid_cells.append(shapely.geometry.box(x0, y0, x1, y1)  )
cell = gpd.GeoDataFrame(grid_cells, columns=['geometry'], 
                                 crs='EPSG:4326')


# Cartographie pour contrôle
ax = VelibParis.plot(markersize=1, figsize=(12, 8))
plt.autoscale(False)
cell.plot(ax=ax, facecolor="none", edgecolor='grey')
ax.axis("off")


```




    (2.2298421041179997, 2.471534953582, 48.8119800955, 48.905228081100006)




![png](output_86_1.png)



```python
#Jointure spatiale Velibs<>Grille

merged = gpd.sjoin(VelibParis, cell, how='left', op='within')
merged.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>ebike</th>
      <th>capacity</th>
      <th>name</th>
      <th>nom_arrondissement_communes</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>stationcode</th>
      <th>is_installed</th>
      <th>is_renting</th>
      <th>numdocksavailable</th>
      <th>duedate</th>
      <th>is_returning</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>index_right</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>5</td>
      <td>35</td>
      <td>Benjamin Godard - Victor Hugo</td>
      <td>Paris</td>
      <td>8</td>
      <td>3</td>
      <td>16107</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>26</td>
      <td>2021-03-04T12:34:56+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (2.27572 48.86598)</td>
      <td>71.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>3</td>
      <td>18</td>
      <td>Flandrin - Henri Martin</td>
      <td>Paris</td>
      <td>6</td>
      <td>3</td>
      <td>16018</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>12</td>
      <td>2021-03-04T12:43:11+00:00</td>
      <td>OUI</td>
      <td>6304</td>
      <td>Porte Dauphine 4</td>
      <td>H</td>
      <td>75</td>
      <td>75116</td>
      <td>Paris 16e Arrondissement</td>
      <td>751166304</td>
      <td>POINT (2.27242 48.86433)</td>
      <td>71.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>20</td>
      <td>Charonne - Robert et Sonia Delauney</td>
      <td>Paris</td>
      <td>2</td>
      <td>1</td>
      <td>11104</td>
      <td>OUI</td>
      <td>OUI</td>
      <td>18</td>
      <td>2021-03-04T12:44:23+00:00</td>
      <td>OUI</td>
      <td>4411</td>
      <td>Sainte-Marguerite 11</td>
      <td>H</td>
      <td>75</td>
      <td>75111</td>
      <td>Paris 11e Arrondissement</td>
      <td>751114411</td>
      <td>POINT (2.39257 48.85591)</td>
      <td>278.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Agrégation statistique
dissolve = merged.dissolve(by="index_right", aggfunc="sum")
dissolve.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
      <th>ebike</th>
      <th>capacity</th>
      <th>numbikesavailable</th>
      <th>mechanical</th>
      <th>numdocksavailable</th>
      <th>iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>code_iris</th>
    </tr>
    <tr>
      <th>index_right</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>29.0</th>
      <td>POINT (2.25252 48.83866)</td>
      <td>3</td>
      <td>32</td>
      <td>5</td>
      <td>2</td>
      <td>26</td>
      <td>6131</td>
      <td>75</td>
      <td>75116</td>
      <td>751166131</td>
    </tr>
    <tr>
      <th>31.0</th>
      <td>POINT (2.25491 48.85772)</td>
      <td>9</td>
      <td>30</td>
      <td>15</td>
      <td>6</td>
      <td>14</td>
      <td>6177</td>
      <td>75</td>
      <td>75116</td>
      <td>751166177</td>
    </tr>
    <tr>
      <th>34.0</th>
      <td>POINT (2.24942 48.87526)</td>
      <td>9</td>
      <td>66</td>
      <td>26</td>
      <td>17</td>
      <td>40</td>
      <td>6277</td>
      <td>75</td>
      <td>75116</td>
      <td>751166277</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Enrichissement du carroyage
cell.loc[dissolve.index, 'capacity']=dissolve.capacity.values
del dissolve
cell.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
      <th>capacity</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>POLYGON ((2.23350 48.81622, 2.23350 48.82354, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>POLYGON ((2.23350 48.82354, 2.23350 48.83087, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>POLYGON ((2.23350 48.83087, 2.23350 48.83819, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>POLYGON ((2.23350 48.83819, 2.23350 48.84551, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>POLYGON ((2.23350 48.84551, 2.23350 48.85284, ...</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Verification somme

total1 = VelibParis['capacity'].sum()
total2 = cell['capacity'].sum()

print(total1)
print(total2)
```

    32189
    32139.0
    


```python
#Cartographie du carroyage

CarroyageVelib, ax = plt.subplots(figsize=(15,15))
cell.to_crs('EPSG:3857').plot(ax=ax, column='capacity', figsize=(12, 8), k=6, cmap='RdBu_r', scheme='quantiles', edgecolor="grey", alpha=0.7, legend = 'true')
ax.axis("off")
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)
plt.title("Nombre d'emplacements de vélibs par IRIS / Ville de Paris", loc='left', fontsize=20)
plt.show()
```


![png](output_91_0.png)


####Nombre d'arbres


```python
# Définir l'emprise de la grille
xmin, ymin, xmax, ymax= ArbresParis.total_bounds

# Paramètrer le nombre de cellule
n_cells=100
cell_size = (xmax-xmin)/n_cells

# Création des cellules
grid_cells = []
for x0 in np.arange(xmin, xmax+cell_size, cell_size ):
    for y0 in np.arange(ymin, ymax+cell_size, cell_size):
        # bounds
        x1 = x0-cell_size
        y1 = y0+cell_size
        grid_cells.append(shapely.geometry.box(x0, y0, x1, y1)  )
cell = gpd.GeoDataFrame(grid_cells, columns=['geometry'], 
                                 crs='EPSG:4326')


# Cartographie pour contrôle
ax = ArbresParis.plot(markersize=1, figsize=(12, 8))
plt.autoscale(False)
cell.plot(ax=ax, facecolor="none", edgecolor='grey')
ax.axis("off")
cell

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>POLYGON ((2.22363 48.81574, 2.22363 48.81816, ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>POLYGON ((2.22363 48.81816, 2.22363 48.82057, ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>POLYGON ((2.22363 48.82057, 2.22363 48.82299, ...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>POLYGON ((2.22363 48.82299, 2.22363 48.82540, ...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>POLYGON ((2.22363 48.82540, 2.22363 48.82782, ...</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>3732</th>
      <td>POLYGON ((2.46516 48.89303, 2.46516 48.89545, ...</td>
    </tr>
    <tr>
      <th>3733</th>
      <td>POLYGON ((2.46516 48.89545, 2.46516 48.89786, ...</td>
    </tr>
    <tr>
      <th>3734</th>
      <td>POLYGON ((2.46516 48.89786, 2.46516 48.90028, ...</td>
    </tr>
    <tr>
      <th>3735</th>
      <td>POLYGON ((2.46516 48.90028, 2.46516 48.90269, ...</td>
    </tr>
    <tr>
      <th>3736</th>
      <td>POLYGON ((2.46516 48.90269, 2.46516 48.90511, ...</td>
    </tr>
  </tbody>
</table>
<p>3737 rows × 1 columns</p>
</div>




![png](output_93_1.png)



```python
#Jointure spatiale Arbres<>Carroyage

merged2 = gpd.sjoin(ArbresParis, cell, how='left', op='within')
merged2.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>index_right</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2029277</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
      <td>48.8910678703</td>
      <td>2.39818911237</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39819 48.89107)</td>
      <td>2695.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>195778</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>8</td>
      <td>48.9001235785,2.38322501988</td>
      <td>48.9001235785</td>
      <td>2.38322501988</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38323 48.90012)</td>
      <td>2476.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# make a simple count variable that we can sum
merged2['idbase']=1
merged2.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>idbase</th>
      <th>domanialite</th>
      <th>arrondissement</th>
      <th>libellefrancais</th>
      <th>hauteurenm</th>
      <th>geo_point_2d</th>
      <th>Latitude</th>
      <th>Longitude</th>
      <th>iris</th>
      <th>nom_iris</th>
      <th>typ_iris</th>
      <th>dep</th>
      <th>insee_com</th>
      <th>nom_com</th>
      <th>code_iris</th>
      <th>geometry</th>
      <th>index_right</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>DJS</td>
      <td>PARIS 19E ARRDT</td>
      <td>Copalme</td>
      <td>5</td>
      <td>48.8910678703,2.39818911237</td>
      <td>48.8910678703</td>
      <td>2.39818911237</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.39819 48.89107)</td>
      <td>2695.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>PERIPHERIQUE</td>
      <td>PARIS 19E ARRDT</td>
      <td>Pin</td>
      <td>8</td>
      <td>48.9001235785,2.38322501988</td>
      <td>48.9001235785</td>
      <td>2.38322501988</td>
      <td>7401</td>
      <td>Pont de Flandre 1</td>
      <td>H</td>
      <td>75</td>
      <td>75119</td>
      <td>Paris 19e Arrondissement</td>
      <td>751197401</td>
      <td>POINT (2.38323 48.90012)</td>
      <td>2476.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Compute stats per grid cell -- aggregate fires to grid cells with dissolve
dissolve = merged2.dissolve(by="index_right", aggfunc="sum")
# put this into cell
cell.loc[dissolve.index, 'idbase']=dissolve.idbase.values
del dissolve

cell.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>geometry</th>
      <th>idbase</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>POLYGON ((2.22363 48.81574, 2.22363 48.81816, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>POLYGON ((2.22363 48.81816, 2.22363 48.82057, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2</th>
      <td>POLYGON ((2.22363 48.82057, 2.22363 48.82299, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>POLYGON ((2.22363 48.82299, 2.22363 48.82540, ...</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>POLYGON ((2.22363 48.82540, 2.22363 48.82782, ...</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
CarroyageArbres, ax = plt.subplots(figsize=(15,15))
cell.to_crs('EPSG:3857').plot(ax=ax, column='idbase', figsize=(12, 8), k=6, cmap='Greens', scheme='quantiles', edgecolor="grey", alpha=0.7, legend = 'true')
ax.axis("off")
ctx.add_basemap(ax, source=ctx.providers.CartoDB.Positron)
plt.show()
```


![png](output_97_0.png)


### Méthode 2 > H3 Uber Index

* https://eng.uber.com/h3/
* https://h3geo.org/docs/usecases
* https://h3geo.org/docs/core-library/restable



```python
# Install H3Index (UBER)
!pip install h3
from h3 import h3
```


```python
#Création du maillage

h3_level = 10
 
def lat_lng_to_h3(row):
    return h3.geo_to_h3(
      row.geometry.y, row.geometry.x, h3_level)
 
ArbresParis['h3'] = ArbresParis.apply(lat_lng_to_h3, axis=1)
```


```python
#Dénombrement des arbres par maille

counts = ArbresParis.groupby(['h3']).h3.agg('count').to_frame('count').reset_index()
counts.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>h3</th>
      <th>count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8a1fb460d827fff</td>
      <td>65</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8a1fb460d82ffff</td>
      <td>8</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8a1fb460d837fff</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8a1fb460d907fff</td>
      <td>95</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8a1fb460d90ffff</td>
      <td>122</td>
    </tr>
  </tbody>
</table>
</div>




```python
#Nombre de mailles
counts["h3"].size
```




    5657




```python
#Verification somme des arbes

total1 = ArbresParis['idbase'].size
total2 = counts['count'].sum()

print(total1)
print(total2)
```

    178735
    178735
    


```python
# Création de la géométrie du maillage 

from shapely.geometry import Polygon
def add_geometry(row):
    points = h3.h3_to_geo_boundary(
      row['h3'], True)
    return Polygon(points)
 
counts['geometry'] = counts.apply(add_geometry, axis=1)
Mailage = gpd.GeoDataFrame(counts, crs='EPSG:4326')
Mailage.plot()
Mailage.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>h3</th>
      <th>count</th>
      <th>geometry</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>8a1fb460d827fff</td>
      <td>65</td>
      <td>POLYGON ((2.27124 48.82880, 2.27034 48.82864, ...</td>
    </tr>
    <tr>
      <th>1</th>
      <td>8a1fb460d82ffff</td>
      <td>8</td>
      <td>POLYGON ((2.27286 48.82848, 2.27196 48.82832, ...</td>
    </tr>
    <tr>
      <th>2</th>
      <td>8a1fb460d837fff</td>
      <td>2</td>
      <td>POLYGON ((2.27015 48.82799, 2.26925 48.82783, ...</td>
    </tr>
    <tr>
      <th>3</th>
      <td>8a1fb460d907fff</td>
      <td>95</td>
      <td>POLYGON ((2.26910 48.83024, 2.26820 48.83007, ...</td>
    </tr>
    <tr>
      <th>4</th>
      <td>8a1fb460d90ffff</td>
      <td>122</td>
      <td>POLYGON ((2.27072 48.82992, 2.26982 48.82976, ...</td>
    </tr>
  </tbody>
</table>
</div>




![png](output_104_1.png)



```python
# Cartographie

H3Map, ax = plt.subplots(figsize=(18,16))
Mailage.to_crs('EPSG:3857').plot(ax=ax, column='count', figsize=(15, 10),k=6, cmap='Greens', scheme='quantiles')
ARDT.boundary.to_crs('EPSG:3857').plot(ax=ax, linewidth=1.2, color = 'black')
ctx.add_basemap(ax,  source=ctx.providers.CartoDB.Positron)
plt.title("Nombre d'arbes par maille H3 (niveau 10) / Ville de Paris", loc='left', fontsize=20)
ax.axis("off")
plt.show()

```


![png](output_105_0.png)

